package c_contentsList

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.fridgeguardian.R

class ContentRVAdapter(val items : ArrayList<String>) : RecyclerView.Adapter<ContentRVAdapter.Viewholder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContentRVAdapter.Viewholder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.content_rv_item,parent,false)
        return Viewholder(v)
    }
    //위에 코드는 꿀팁페이지에서 양식 탭을 누르면, 양식에 관련된 레시피들을 하나하나 가져와서 각각 하나의 레이아웃을 만들어줌

    override fun onBindViewHolder(holder: ContentRVAdapter.Viewholder, position: Int) {
        holder.bindItems(items[position])
    }
    //여기는 양식 카테고리에 있는 레시피 하나하나들을 밑에 innerclass Viewholder가서 하나씩 연결해주고 있는거임

    override fun getItemCount(): Int {
        return items.size
    }
    //이건 전체 아이템의 수가 몇개인지, 양식 카테고리 눌렀을 때 글이 몇개 뜨냐고

    inner class Viewholder(itemView : View) : RecyclerView.ViewHolder(itemView){
        fun bindItems(item : String){

        }
    }
}
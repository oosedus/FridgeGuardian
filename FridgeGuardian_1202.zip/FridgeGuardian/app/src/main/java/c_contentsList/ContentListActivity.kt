package c_contentsList

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fridgeguardian.R

class ContentListActivity : AppCompatActivity() {
    //리사이클러뷰를 통해서 tip페이지에서 원하는 음식 카테고리를 클릭하면 해당 카테고리의 꿀팁들이 보일 수 있게함
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_content_list)


        val rv : RecyclerView = findViewById(R.id.rv)

        val items = ArrayList<String>()
        items.add("a")
        items.add("b")
        items.add("c")
        items.add("d")


        val rvAdapter = ContentRVAdapter(items)
        rv.adapter=rvAdapter


        //그리드 레이아웃 쓰면 2개씩 보이게 할 수 있음
        rv.layoutManager = GridLayoutManager(this,2)


    }
}
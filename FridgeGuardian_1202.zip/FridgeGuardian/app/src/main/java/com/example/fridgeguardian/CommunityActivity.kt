package com.example.fridgeguardian

class CommunityActivity {
}
package com.example.fridgeguardian

class RecipeActivity {
}
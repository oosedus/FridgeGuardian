package com.example.fridgeguardian

class MyPageActivity {
}
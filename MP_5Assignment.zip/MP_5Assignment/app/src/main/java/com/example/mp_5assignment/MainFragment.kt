package com.example.mp_5assignment

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout

class MainFragment : Fragment() {
    private var listener: OnDataPass? = null
    private lateinit var personalInfoLayout: LinearLayout
    private lateinit var addressInfoLayout: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_main, container, false)

        personalInfoLayout = view.findViewById(R.id.layout_personal_info)
        addressInfoLayout = view.findViewById(R.id.layout_address_info)

        val buttonNext = view.findViewById<Button>(R.id.button_next)
        val editName = view.findViewById<EditText>(R.id.edit_name)
        val editAge = view.findViewById<EditText>(R.id.edit_age)
        val editStudentNumber = view.findViewById<EditText>(R.id.edit_student_number)

        buttonNext.setOnClickListener {
            listener?.onDataPass(editName.text.toString(), editAge.text.toString(), editStudentNumber.text.toString())
            personalInfoLayout.visibility = View.GONE
            addressInfoLayout.visibility = View.VISIBLE
        }

        return view
    }

    interface OnDataPass {
        fun onDataPass(name: String, age: String, studentNumber: String)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnDataPass) {
            listener = context
        } else {
            throw RuntimeException("$context must implement OnDataPass")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    companion object {
        @JvmStatic
        fun newInstance() = MainFragment()
    }
}

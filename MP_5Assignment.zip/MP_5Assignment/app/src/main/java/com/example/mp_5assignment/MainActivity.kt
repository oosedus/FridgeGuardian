package com.example.mp_5assignment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity(), MainFragment.OnDataPass {
    lateinit var mainFragment: MainFragment
    lateinit var subFragment: SubFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // MainFragment는 처음에 추가하지 않습니다.
        subFragment = SubFragment.newInstance()

        supportFragmentManager.beginTransaction()
            .replace(R.id.sub_container, subFragment)
            .commit()

        findViewById<Button>(R.id.btn_add_member).setOnClickListener {
            // "Add new member" 버튼을 눌렀을 때 MainFragment를 추가합니다.
            mainFragment = MainFragment.newInstance()
            supportFragmentManager.beginTransaction()
                .replace(R.id.main_container, mainFragment)
                .commit()
        }
    }

    override fun onDataPass(name: String, age: String, studentNumber: String) {
        if(::subFragment.isInitialized){
            subFragment.displayData(name, age, studentNumber)
        }
    }
}


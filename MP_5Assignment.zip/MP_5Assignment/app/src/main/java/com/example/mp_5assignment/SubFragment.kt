package com.example.mp_5assignment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [SubFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class SubFragment : Fragment() {
    private lateinit var textName: TextView
    private lateinit var textAge: TextView
    private lateinit var textStudentNumber: TextView
    private var isViewCreated = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_sub, container, false)

        textName = view.findViewById(R.id.text_name)
        textAge = view.findViewById(R.id.text_age)
        textStudentNumber = view.findViewById(R.id.text_student_number)
        isViewCreated = true

        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        isViewCreated = false
    }

    fun displayData(name: String, age: String, studentNumber: String) {
        if (isViewCreated) {
            textName.text = name
            textAge.text = age
            textStudentNumber.text = studentNumber
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() = SubFragment()
    }
}

